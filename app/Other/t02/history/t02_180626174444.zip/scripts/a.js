// JavaScript Document

/*let p01 = 1234;
let p02 = 2123;
let p03 = 5665;
let p04 = 2321;
let p05 = 176;
let p06 = 11224;
let p07 = 974;
let p08 = 112355555;

function action(num = 200) {
	console.log(num)
}

action() //200
action(300) //300

const name = 'lux'; //# const => var

const template = `<div>
	<span>hello world</span>
</div>`; //# 字符串换行

[1,2,3].map( x => x + 1 );
var people1 = name => 'hello' + name*/
/*const name = 'lux'; //# 常量
name= "AD723"; //# 赋值。



//## 函数语法有所改变


//## ???这句什么意思
[1,2,3].map( x => x + 1 )


//## 函数表达式???!!


var people2 = (name, age) => {
	const fullName = 'h' + name
	return fullName
} */

var hhhhhjhhhhh ="这是一段很长很长的文字这是一段很长很长的文字这是一段很长很长的文字这是一段很长很长的文字这是一段很长很长的文字";
var xahdkjshadjkas = "aaasgdhgdhasjdgdghagxzvbcnxzvbcnzvcbnzxvzxbnvbn";
var oooo = "sadsakhdasjkak11111";
var ssd = {a:123456789};
var sssd = "sdbn!!!!!!!"