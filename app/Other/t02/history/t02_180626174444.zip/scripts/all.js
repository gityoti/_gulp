$(function(){
	alert(123456);	
});

var x = [1,2,3,4,5,6,7];
var j = {a:1,b:2,c:3,d:4};
var shjdkdhasjk = 21312;
var ks = "sadhasjkhdasjkdhajk";

(function(){
	
	console.log("sadshafdsgha11111");
})();

//# 函数内只允许出现1次var
function J(){
	var x = 1;
	var b = 2;
	var c = 3;
}

//## 禁止下划线开头结尾
var _x = 9999;
var x_ = 9999;

var dss     = [ "ss" ,"asdas"  ];

//# 未使用var 声明
abcs = 999;