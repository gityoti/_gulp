// index.js
//import("scripts/widget/a.js");
//import("scripts/widget/b.js");
//import("scripts/widget/c.js");
//import("scripts/a.js");

// index.js end
var aa ='这是主文件';
//# 为什么导入失败???
var sd = 1;
var ab = '11111';
var vv = '781'

//## import 导入的文件无法立刻生效 ==> 大概是缓存的缘故吧??? ==> 把缓存部分删除可以不?